package org.senro.ui.control;

import java.util.HashSet;
import java.util.Set;

import org.senro.gwt.client.assoc.impl.SenroAssoc;

public class AssociationRegistry {
	private static Set<SenroAssoc> associations = new HashSet<SenroAssoc>();
	
	public static void register(SenroAssoc assoc) {
		associations.add(assoc);
	}
	
	public static Set<SenroAssoc> getAll() {
		return associations;
	}
	
	public static SenroAssoc get(String className) {
		for( SenroAssoc assoc : getAll() ) {
			if( assoc.getClass().getName().equals(className) )
				return assoc;
		}
		return null;
	}
}
