package org.senro.ui.template;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.senro.exception.SenroTemplateException;
import org.senro.gwt.client.model.ui.binding.ComponentAssociation;
import org.senro.gwt.client.model.ui.binding.Model;
import org.senro.gwt.client.model.ui.binding.StringModelObject;
import org.senro.ui.template.model.BasicComponentType;
import org.senro.ui.template.model.ConditionalType;
import org.senro.ui.template.model.ElseType;
import org.senro.ui.template.model.GridAllocatorRendererType;
import org.senro.ui.template.model.GridType;
import org.senro.ui.template.model.IfType;
import org.senro.ui.template.model.IteratorType;
import org.senro.ui.template.model.ListType;
import org.senro.ui.template.model.Server;
import org.senro.ui.template.model.SwitchComponentType;
import org.senro.ui.template.model.TemplateType;
import org.senro.ui.template.model.TreeNodeType;
import org.senro.ui.template.model.UIComponentType;
import org.senro.ui.template.model.TemplateType.Param;
import org.senro.ui.template.sid.SIDCellLayout;
import org.senro.ui.template.sid.SIDComponent;
import org.senro.ui.template.sid.SIDComponent.KeyValuePair;
import org.springframework.util.Assert;

public class SIDTemplateRenderer extends TemplateRenderer<SIDComponent> {
	public SIDTemplateRenderer() {
	}
	
	@Override
	protected SIDComponent renderSwitchComponent(SwitchComponentType uiComponent, boolean generateId) throws SenroTemplateException {
		Assert.notNull(uiComponent);
		SIDComponent result = new SIDComponent();
		result.setRenderComponent(ComponentAssociation.SWITCHCOMPONENT);
		return result;
	}
	
	@Override
	public List<SIDComponent> renderIterator(IteratorType iterator, boolean generateId) throws SenroTemplateException {
		SIDComponent result = new SIDComponent();
		result.setRenderComponent(ComponentAssociation.ITERATOR);
		if( iterator.getLabelOrTextFieldOrTextArea().size() == 0 ) {
			throw new SenroTemplateException("Iterator content is empty for: "+iterator.getName());
		}
		else if( iterator.getLabelOrTextFieldOrTextArea().size() > 1 ) {
			throw new SenroTemplateException("Iterator is restricted to only one component: "+iterator.getName());
		}

		result.put(SIDComponent.LIST, iterator.getList());
		result.put(SIDComponent.FILTERCONDITION, iterator.getFilterCondition());
		Object iteratorComponent = iterator.getLabelOrTextFieldOrTextArea().get(0);
		if( iteratorComponent instanceof UIComponentType )
			result.add( renderGeneric((UIComponentType) iteratorComponent, false) );
		else if( iteratorComponent instanceof TreeNodeType )
			result.add( renderTreeNode((TreeNodeType) iteratorComponent, false) );
		
		return Collections.singletonList(result);
	}
	
	@Override
	public List<SIDComponent> renderConditional(ConditionalType conditional, boolean generateId) throws SenroTemplateException {
		SIDComponent result = new SIDComponent();
		result.setRenderComponent(ComponentAssociation.CONDITIONAL);
		
		IfType ifType = conditional.getIf();
		result.put(SIDComponent.IFCONDITION, ifType.getCondition());
		result.add( renderGeneric(ifType.getLabelOrTextFieldOrTextArea().iterator().next(), false) );
		
		ElseType elseType = conditional.getElse();
		if(elseType != null)
			result.add( renderGeneric(elseType.getLabelOrTextFieldOrTextArea().iterator().next(), false) );
		
		return Collections.singletonList(result);
	}
	
	@Override
	public SIDComponent renderTreeNode(TreeNodeType treeNode, boolean generateId)
			throws SenroTemplateException 
	{
		SIDComponent result = new SIDComponent();
		result.setRenderComponent(ComponentAssociation.TREENODE);
		result.setModel(new Model<StringModelObject>(new StringModelObject( treeNode.getText() )));
		return result;
	}

	
	@Override
	protected SIDComponent renderList(ListType uiComponent,
			boolean generateId) throws SenroTemplateException 
	{
		SIDComponent component = new SIDComponent();
		component.setRenderComponent(ComponentAssociation.LIST);
		return component;
	}
	
	@Override
	public SIDComponent renderGridAllocatorRenderer(
			GridAllocatorRendererType gridAllocatorRenderer, boolean generateId)
			throws SenroTemplateException 
	{
		SIDComponent component = new SIDComponent();
		component.setRenderComponent(ComponentAssociation.GRIDALLOCATORRENDERER);
		component.put(SIDComponent.GRIDALLOCATOR, gridAllocatorRenderer.getGridAllocator());
		return component;
	}
	
	@Override
	protected SIDComponent renderTemplate(TemplateType uiComponent, boolean generateId) throws SenroTemplateException {
		SIDComponent component = new SIDComponent();
		component.setRenderComponent(ComponentAssociation.TEMPLATE);
		component.put(SIDComponent.FILE, uiComponent.getFile());
		List<KeyValuePair> params = new ArrayList<KeyValuePair>();
		for(Param param : uiComponent.getParam()) {
			params.add(new KeyValuePair(param.getName(), param.getValue()));
		}
		component.put(SIDComponent.PARAMS, params);
		return component;
	}

	@Override
	public SIDComponent renderGrid(GridType grid, boolean generateId) throws SenroTemplateException {
		return new SIDComponent(super.renderGrid(grid, generateId));
	}
	
	@Override
	public void renderServer(Server server) throws SenroTemplateException {
	}
	
	@Override
	public String evaluate(String expression) throws SenroTemplateException {
		return expression;
	}
	
	@Override
	protected void addVariable(BasicComponentType component) throws SenroTemplateException {
	}
	
	protected SIDCellLayout buildCellLayout(UIComponentType componentType) throws SenroTemplateException {
		SIDCellLayout layout = new SIDCellLayout();
		layout.setStrRow(componentType.getRow());
		layout.setStrColumn(componentType.getCol());
		layout.setStrRowSpan(componentType.getRowSpan());
		layout.setStrColSpan(componentType.getColSpan());
		return layout;
	}
}
