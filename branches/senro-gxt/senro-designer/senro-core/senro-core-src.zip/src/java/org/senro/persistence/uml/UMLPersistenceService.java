package org.senro.persistence.uml;

import java.util.List;

import org.senro.persistence.dummy.DummyPersistenceService;

public class UMLPersistenceService extends DummyPersistenceService {
	@Override
	public List getAllTypes() {
		return super.getAllTypes();
	}
}
