package org.senro.gwt.client.assoc;

import java.util.List;
import java.util.Map;

import org.senro.gwt.client.model.ui.SenroComponent;

public interface Assoc {
	void 	establishConnection();
	void 	breakConnection();
	Map<String, SenroAspect> getAspects();
	Map<String, SenroComponent<?>> getBindings();
	
	List<Assoc> associationClassesForObject(Object anObject);
	List<Assoc> associationClassesSuperseded();
	boolean isUsableWithObject(Object anObject);
	
	void bind(String key, Object value, SenroAspect aspect);
	boolean canBind(String key, Object value, SenroAspect aspect);
	void copyMatchingBindingsFromAssociation(Assoc anAssociation);
	Object valueForBinding(String anAspect);
}
