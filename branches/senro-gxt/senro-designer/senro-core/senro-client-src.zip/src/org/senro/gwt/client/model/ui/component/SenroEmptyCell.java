package org.senro.gwt.client.model.ui.component;

import com.extjs.gxt.ui.client.widget.ContentPanel;

public class SenroEmptyCell extends ContentPanel {
	public SenroEmptyCell() {
		setHeaderVisible(false);
		setBorders(false);
		setFrame(false);
		setBodyBorder(false);
	}
}
