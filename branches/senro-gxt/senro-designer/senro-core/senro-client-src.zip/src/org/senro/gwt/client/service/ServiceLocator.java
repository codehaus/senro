package org.senro.gwt.client.service;

/**
 * @author FlaviusB
 */
public interface ServiceLocator {
	public static final String BASE_URL="http://localhost:8888/";
}
