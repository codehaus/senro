package org.senro.gwt.client.model;

public interface DataObject {

}
