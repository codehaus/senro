package org.senro.gwt.client.mvc;

/**
 * @author FlaviusB
 */
public class SenroEvents {
	public static final String KEY = "data";
	
	public static final int Init = 0;
    public static final int Error = -1;
    public static final int Render = 1;
}
