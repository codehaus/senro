package org.senro.gwt.client.control;

public class Qualifier {

}
