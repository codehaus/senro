package org.senro.gwt.client.control;

public interface ObjectStore {

}
