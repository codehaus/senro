package org.senro.ui.template.sid;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.PropertyUtils;
import org.senro.gwt.client.model.ui.SenroContainerComponent;

public class SIDComponent extends SenroContainerComponent<SIDComponent> implements Map<String, Object>{
	private Map<String, Object> delegate = new HashMap<String, Object>();
	
	public SIDComponent() {
	}
	
	public SIDComponent(String id) {
		super(id);
	}

	public SIDComponent(SenroContainerComponent<SIDComponent> copy) {
		this();
		try {
			PropertyUtils.copyProperties(this, copy);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void clear() {
		delegate.clear();
	}

	@Override
	public boolean containsKey(Object key) {
		return delegate.containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		return delegate.containsValue(value);
	}

	@Override
	public Set<java.util.Map.Entry<String, Object>> entrySet() {
		return delegate.entrySet();
	}

	@Override
	public Object get(Object key) {
		return delegate.get(key);
	}

	@Override
	public boolean isEmpty() {
		return delegate.isEmpty();
	}

	@Override
	public Set<String> keySet() {
		return delegate.keySet();
	}

	@Override
	public Object put(String key, Object value) {
		return delegate.put(key, value);
	}

	@Override
	public void putAll(Map<? extends String, ? extends Object> m) {
		delegate.putAll(m);
	}

	@Override
	public Object remove(Object key) {
		return delegate.remove(key);
	}

	@Override
	public int size() {
		return delegate.size();
	}

	@Override
	public Collection<Object> values() {
		return delegate.values();
	}
	
	public static class KeyValuePair {
        public Object key;
        public Object value;
        
        public KeyValuePair(Object key, Object value) {
            this.key = key;
            this.value = value;
        }
        boolean equals(KeyValuePair pair) {
            return pair.key == this.key;
        }
    }
	
	@Override
	public String toString() {
		return super.toString()+", Properties: "+delegate;
	}
}
