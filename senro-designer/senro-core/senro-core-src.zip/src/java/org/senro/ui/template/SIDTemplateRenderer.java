package org.senro.ui.template;

import java.util.ArrayList;
import java.util.List;

import org.senro.exception.SenroTemplateException;
import org.senro.ui.template.model.GridType;
import org.senro.ui.template.model.IteratorType;
import org.senro.ui.template.model.UIComponentType;
import org.senro.ui.template.sid.SIDCellLayout;
import org.senro.ui.template.sid.SIDComponent;

public class SIDTemplateRenderer extends TemplateRenderer<SIDComponent> {
	public SIDTemplateRenderer() {
	}
	
	@Override
	public SIDComponent renderGrid(GridType grid, boolean generateId) throws SenroTemplateException {
		return new SIDComponent(super.renderGrid(grid, generateId));
	}
	
	@Override
	public List<SIDComponent> renderIterator(IteratorType iterator, boolean generateId) throws SenroTemplateException {
		String list = iterator.getList();
		Object result = evaluate(list);
		if( !list.equals(result) )
			return super.renderIterator(iterator, generateId);
		else {
			List<SIDComponent> components = new ArrayList<SIDComponent>();
			SIDComponent sidComponent = new SIDComponent();
			
			return components;
		}
	}

	@Override
	public <K> K evaluate(String expression) throws SenroTemplateException {
		try {
			return (K) super.evaluate(expression);
		} catch( Throwable t ) {
			return (K) expression;
		}
	}
		
	protected SIDCellLayout buildCellLayout(UIComponentType componentType) throws SenroTemplateException {
		SIDCellLayout layout = new SIDCellLayout();
		layout.setStrRow(componentType.getRow());
		layout.setStrColumn(componentType.getCol());
		layout.setStrRowSpan(componentType.getRowSpan());
		layout.setStrColSpan(componentType.getColSpan());
		return layout;
	}
}
